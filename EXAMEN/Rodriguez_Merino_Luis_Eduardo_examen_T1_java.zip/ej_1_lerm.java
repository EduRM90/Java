//Luis Eduardo Rodríguez Merino
public class ej_1_lerm 
{

    public static void main(String args[]) 
    {
       char vocal='a';
       String nombre="Edu";
       byte dividendo=12;
       int divisor=1256;
       long pass=321795642;
       double ancho=0.98;
       float resultado = dividendo/divisor;
       boolean aprueba=true;
            
    }
}
